<?php

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

trait ${NAME} {

}